//--------------------------------------------------------------------------
//
//    This file is part of GenePool Swimbots.
//    Copyright (c) 2021 by Jeffrey Ventrella - All Rights Reserved.
//
//    See the README file or go to swimbots.com for full license details.
//    You may use, distribute, and modify this code only under the terms
//    of the "Commons Clause" license (commonsclause.com).
//
//    This software is intended for education, game design, and research.
//
// --------------------------------------------------------------------------

"use strict";

//--------------------------
const ALLOW_SWIMBOT_MANIPULATION = false;
const FIRST_INFO_PAGE = 1;
const LAST_INFO_PAGE  = 28;

const DEFAULT_BASIC_PANEL_COLOR         = "#caccc2";
const DEFAULT_BASIC_BUTTON_COLOR        = "#dadad0";
const DEFAULT_BASIC_BUTTON_BORDER_COLOR = "#7f7f77";
const ACTIVE_BORDER_COLOR               = '#ffffff';

const UI_UPDATE_PERIOD = 100;
const LEADERBOARD_UPDATE_MULTIPLE = 20;
var UI_UPDATE_COUNTER = 0;


let _currentInfoPage            = FIRST_INFO_PAGE;
let _graph                      = new Graph();
let _tweakGenesCategory         = 0;
let _runningFast                = false;


//----------------------------
function initializeUI()
{
    //--------------------------------------------------
    // This starts an update loop that is called
    // periodically to adjust UI states and stuff.
    //--------------------------------------------------
    //console.log( "setTimeout" );

    setTimeout( "updateUI()", 1 );
 }



//----------------------------------
function toggleSimulationRunning()
{
    if ( genePool.getSimulationRunning() )
    {
        genePool.setSimulationRunning( false );
        document.getElementById( "pausePlayButton" ).src = "images/play-on.png";
    }
    else
    {
        genePool.setSimulationRunning( true );
        document.getElementById( "pausePlayButton" ).src = "images/pause-on.png";
    }
    return(false);
}

//----------------------------------
function toggleFastRendering()
{
    if ( _runningFast )
    {
        _runningFast = false;
        genePool.setMillisecondsPerUpdate( DEFAULT_MILLISECONDS_PER_UPDATE );
        document.getElementById( "fastButton" ).style = "border-color: " + DEFAULT_BASIC_BUTTON_BORDER_COLOR
    }
    else
    {
        _runningFast = true;
        genePool.setMillisecondsPerUpdate(0);
        document.getElementById( "fastButton" ).style.borderColor       = ACTIVE_BORDER_COLOR;
        document.getElementById( "fastButton" ).style.borderWidth =  "3px";
    }
}


//-------------------------
function toggleRendering()
{
    if ( genePool.getRendering() )
    {
        setRendering( false );
    }
    else
    {
        setRendering( true );
    }
}

//-------------------------
function setRendering(r)
{
    if ( r )
    {
        genePool.setRendering( true );
        //document.getElementById( "noRenderButton" ).style = "border-color: " + DEFAULT_BASIC_BUTTON_BORDER_COLOR
        //document.getElementById( "noRenderButton" ).style.zIndex = '4';
        //document.getElementById( "noRenderButton" ).style.zIndex = '1';



        canvasID.style.visibility = 'visible';

        /*
        _runningFast = false;
        genePool.setMillisecondsPerUpdate( 20 );
        document.getElementById( "fastButton" ).style = "border-color: #666659;"
        */
    }
    else
    {
        genePool.setRendering( false );
        //document.getElementById( "noRenderButton" ).style = "border-color: " + ACTIVE_BORDER_COLOR + ";"
        //document.getElementById( "noRenderButton" ).style.borderWidth =  "3px";

        //document.getElementById( "noRenderButton" ).style.content = 'fdf';


        //document.getElementById( "noRenderButton" ).style.zIndex = '4';
        canvasID.style.visibility = 'hidden';
        document.getElementById( "noRenderPanel" ).style.visibility = 'visible';

        /*
        _runningFast = true;
        genePool.setMillisecondsPerUpdate(0);
        document.getElementById( "fastButton" ).style = "border-color: " + ACTIVE_BORDER_COLOR + ";"
        */
    }
}



//--------------------------------------
function requestToLoadPoolFromPreset()
{
    console.log( "requestToLoadPool " + _chosenPoolToLoad );

    //----------------------------------------
    // get the name of the pool to load...
    //----------------------------------------
    let poolText = "(ERROR)";

         if ( _chosenPoolToLoad === SimulationStartMode.RANDOM         ) { poolText = "'random'";        }
    else if ( _chosenPoolToLoad === SimulationStartMode.NEIGHBORHOOD   ) { poolText = "'neighborhood'";  }
    else if ( _chosenPoolToLoad === SimulationStartMode.FROGGIES       ) { poolText = "'froggies'";      }
    else if ( _chosenPoolToLoad === SimulationStartMode.TANGO          ) { poolText = "'tango'";         }
    else if ( _chosenPoolToLoad === SimulationStartMode.RACE           ) { poolText = "'race'";          }
    else if ( _chosenPoolToLoad === SimulationStartMode.BIG_BANG       ) { poolText = "'big bang'";      }
    else if ( _chosenPoolToLoad === SimulationStartMode.BAD_PARENTS    ) { poolText = "'bad parents'";   }
    else if ( _chosenPoolToLoad === SimulationStartMode.EMPTY          ) { poolText = "'empty'";         }
    else if ( _chosenPoolToLoad === SimulationStartMode.FXHASH         ) { poolText = "'fxhash NFTs'";         }
    //else if ( _chosenPoolToLoad === SimulationStartMode.FILE           ) { poolText = "from file";       }

    //---------------------------------------------------------------------------------------
    // this overrides the UI asking the user to save the current pool first...
    //---------------------------------------------------------------------------------------
    switchToChosenPresetPool();


}

//-------------------------------
function choosePoolToLoad( pool )
{
    _chosenPoolToLoad = pool;
}


//----------------------------------
function switchToChosenPresetPool()
{
    //console.log( "switchToChosenPresetPool" );

    genePool.startSimulation( _chosenPoolToLoad );
    _graph.initialize();
    setRendering( true );

}


//--------------------------------
function loadSwimbotFromPreset(p)
{
    let genes = genePool.getPresetGenotype(p);
    genePool.createNewSwimbotWithGenes( genes );
}





//-----------------------
function updateUI()
{
    //console.log( "updateUI" );
    UI_UPDATE_COUNTER ++;
    //-----------------------------------------------------------------------------------
    // check that we have a genePool......
    //-----------------------------------------------------------------------------------
    let genePoolIsDefined = typeof genePool != 'undefined';

    if ( genePoolIsDefined )
    {
        //-------------
        // NFT Pool UI
        //-------------
        document.getElementById( 'timeCounter' ).innerHTML = genePool.getTimeStep().toLocaleString();

        /* UPDATE LEADERBOARD, but not as often as we update other UI elements since calculations might be expensive
           and we don't want the rankings flipping and flopping around too quickly */
        if (UI_UPDATE_COUNTER % LEADERBOARD_UPDATE_MULTIPLE == 0 || UI_UPDATE_COUNTER == 1) {
          doUpdateLeaderboard();
        }

    }

    //---------------------------
    // trigger next update...
    //---------------------------
    //this.timer = setTimeout( "updateUI()", 100 );
    setTimeout( "updateUI()", UI_UPDATE_PERIOD );
}


// Helper functions. Probably a better place to put this:
// linearly maps value from the range (a..b) to (c..d)
function mapRange (value, a, b, c, d) {
    // first map value from (a..b) to (0..1)
    value = (value - a) / (b - a);
    // then map it from (0..1) to (c..d) and return it
    return c + value * (d - c);
}

// Function to get unique elements of an array
function uniq(a) {
    return a.sort().filter(function(item, pos, ary) {
        return !pos || item != ary[pos - 1];
    });
}

let startingSwimbots = [];

function doUpdateLeaderboard() {

  document.getElementById( 'totalAlive' ).innerHTML = genePool.getNumSwimbots();

  // Useful variables:   //console.log(genePool);
  // get the names of all the genes for extracting Junk
  // couldn't figure out how to do this...
  // genePool.getGeneName();
  let livingSwimbots = genePool.getNumSwimbots();
  // GET ALL CURRENT SWIMBOT DATA TO PLAY WITH HERE:
  let currentSwimbotData = genePool.getPoolData().swimbotArray;
  // Get current timestep:
  let time = genePool.getTimeStep();


  // NOTE: There's a better way to do this with permanent IDs for each swimbot,
  // but couldn't find it. So I'm relying on their entire genome to identify individuals.
  // Loop through the swimbots to make an array of unique identifiers for all the Original
  // swimbots. But do this only once at the start:
  if(time < 300){
    for (let i = 0; i < livingSwimbots; i++) {
      // console.log(currentSwimbotData[i].genes);
      startingSwimbots.push(currentSwimbotData[i].genes.join(", "));
    }
    // also remove duplicate swimbots since we just want a reference for each:
    startingSwimbots = uniq(startingSwimbots)
  }

  //console.log(startingSwimbots);

  // Now loop through all living swimbots to see which ones of the original are still alive,
  // and make an array of living swimbots
  let liveAncestors = [];
  for (let i = 0; i < livingSwimbots; i++) {
    if(startingSwimbots.includes(currentSwimbotData[i].genes.join(", "))) {
      // this adds the junk DNA serial to liveAncestors
      liveAncestors.push(currentSwimbotData[i].genes[200]);
    }
  }
  // remove duplicates due to looping
  liveAncestors = uniq(liveAncestors)
  //console.log(liveAncestors);

  // Here you can get all the data for a selected swimbot:
  //console.log(currentSwimbotData[genePool.getSelectedSwimbotID()]);
  //console.log(genePool);

  // Here is a bunch of code to get the junkGene starting index so we don't have
  // to manually set it:
  let geneNames = [];
  for (let i = 0; i < 256; i++) {
    geneNames.push(genePool.getGeneName(i));
  }
  function checkGenes(gene) {
    return gene.includes("junk")
  }
  const junkGeneIndexStart = geneNames.findIndex(checkGenes);

  // Declare array to hold all the junk genes in the entire pool:
  let individualGenes = [];
  // loop through each living swimbot
  let geneCounter = 0; // counter for storing all of the genes
  for (let s = livingSwimbots; s > 0; s--){
    let genes = genePool.getSwimbotGenes(s);
    // then loop through each gene
    for (let g = junkGeneIndexStart; g < 256; g++){
      individualGenes[geneCounter] = genes[g];
      geneCounter ++;
    }
  }
  //console.log(individualGenes.length); // starting output should be the number of starting swimbots * the number of junkgenes (143)

  //Now analyze genomes to find how many occurences of the junk DNA there are for every ancestral genome:
  // But first, here is a loop that extracts just the original ancestral serial numbers to have as an array for calculating their scores (rather than relying on the length of fxhashGenes.length):
  let ancestors = [];
  for (let j = 0; j < fxhashGenes.length; j++) {
    let junkSerial = fxhashGenes[j][200]; // gene 200 will always be junk DNA
    //then add that to the ancestors array only if it isn't already present:
    if(!ancestors.includes(junkSerial)) {
    ancestors.push(junkSerial);
    }
  }
  //console.log(ancestors);

  // Create a LeaderboardRow class that contains the important variables
  // that are needed plus some of the operations such as creating the HTML row.
  class LeaderboardRow {
    constructor(tempSwimbot, tempScore, tempAlive) {
      this.swimbot = tempSwimbot;
      this.score = tempScore;
      this.htmlRow;
      this.alive = tempAlive; // for the future when we can make the swimbot ID glow if original still alive
    }

    // Give these rows the ability to create an HTML chunk when calling createHTML:
    createHTML() {
      // made the scorebar a bit shorter at its maximum so that the %score fits in.
      // needs to be tested, might still be too long
      let thisScoreBar = mapRange(this.score, 0, 100, 0, 180);
      // glow the swimbot leaderboard if the original is still alive:
      let glowSwimbot;
      if(this.alive) {
        glowSwimbot = "<b> <mark style=\"background-color:#41516b; color:#52db97\">Swimbot #" + this.swimbot + "</mark> </b>"
      } else {
        glowSwimbot = " Swimbot #" + this.swimbot
      }

      this.htmlRow = "<p><a href=\"#\" onClick=\"window.open('../nft/?hash=ooabcdefghijklmnopqrstuvwxyzabcdefg" + this.swimbot + "','nftwindow','directories=no,titlebar=no,toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,width=400,height=400'); return(false);\"><i class=\"fa fa-camera\"></i>" + glowSwimbot + "</a> <span id=\"score442\" style=\"width: " + thisScoreBar + "px;\">&nbsp;</span>  " + this.score + "%</p>"
      return this.htmlRow;
    }
  }

  // First loop through every ancestor:
  let leaderRows = [];
  let completeHTML = '';
  //console.log(ancestors);
  for(let a = 0; a<ancestors.length; a++) {
    let ancestral_total = 0;
    let ancestral_score; // ancestral total divided by total genes

    // Then loop through each individual gene in the whole Pool
    for(let i = 0; i < individualGenes.length; i++) {
      if(individualGenes[i] == ancestors[a]){
        ancestral_total ++;
      }
    }
    //console.log(ancestral_total);

    // calculate the percent of total genes
    ancestral_score = ancestral_total/individualGenes.length*100
    // round to one decimal place
    ancestral_score = ancestral_score.toFixed(1);
    // convert to numeric
    ancestral_score = parseFloat(ancestral_score);

    //Also figure out if the current ancestor is still alive in the pool:
    let alive = liveAncestors.includes(ancestors[a]);

    // then add a new leaderboardRow object to the leaderRows array
    leaderRows[a] = new LeaderboardRow(ancestors[a], ancestral_score, alive);

    // completeHTML = completeHTML + leaderRows[a].createHTML();
  }

  // Now to sort the objects correctly based on score, we have to first
  // create a function that returns -1, 0 , or 1 based on a pairwise comparison of
  // a and b (don't have me explain why this is supposed to work (cite stackoverflow))
  // https://stackoverflow.com/questions/1129216/sort-array-of-objects-by-string-property-value
  // Note that swapping the -1 and 1 will reverse the order of the sort.
  function compare( a, b ) {
    if ( a.score < b.score ){
      return 1;
    }
    if ( a.score > b.score ){
      return -1;
    }
    return 0;
  }

  // Then just simply run the magic sort operation:
  leaderRows.sort(compare);   // IT WORKS!!!

  // Finally, then create the completeHTML chunk by concatonating all the
  // sorted HTML rows of leaderRows:
  for (let i = 0; i < leaderRows.length; i++) {
    completeHTML = completeHTML + leaderRows[i].createHTML();
  }

    // And then create the leaderscores document:
    document.getElementById('leaderScores').innerHTML = completeHTML;
}





function resize()
{
    // console.log('Resizing');
    let circlemask = document.getElementById('circlemask');
    let transportHolder = document.getElementById('transportHolder');
    let zoomHolder = document.getElementById('zoomHolder');
    let counterHolder = document.getElementById('counterHolder');
    let leaderboard = document.getElementById('leaderboard');
    let leaderScores = document.getElementById('leaderScores');
    let restartHolder = document.getElementById('restartHolder');
    circlemask.setAttribute('draggable', false);
    leaderboard.style.display = 'block';

    let height = window.innerHeight;
    let width = window.innerWidth;
    let minOfWidthHeight = Math.min(height,width);
    var reduceSize = 0;

    if (window.innerWidth > (minOfWidthHeight + 200)) {
      // WIDE SCREEN, place elements side-by-side
      reduceSize = 250 + (height / 50);
      leaderboard.style.top = 165; leaderboard.style.left = (height - reduceSize) + 50;
      leaderboard.style.height = minOfWidthHeight - reduceSize - 40;
      leaderScores.style.height = minOfWidthHeight - reduceSize - 160;
      transportHolder.style.left = 250 + Math.max( (height/3)-260 , 0); transportHolder.style.top = 45;
      zoomHolder.style.left = 307 + Math.max( (height/3)-250 , 0); zoomHolder.style.top = 58;
      counterHolder.style.left = 530 + Math.max( (height/3)-260 , 0); counterHolder.style.top = 45;
      restartHolder.style.left = 695 + Math.max( (height/3)-260 , 0); restartHolder.style.top = 52;
    } else {
      // MOBILE/NARROW SCREEN, stack elements
      reduceSize = 75 + ( (width - 400) / 4);
      transportHolder.style.left = 40; transportHolder.style.top = (minOfWidthHeight - reduceSize) + 180;
      zoomHolder.style.left = 108; zoomHolder.style.top = (minOfWidthHeight - reduceSize) + 195;
      counterHolder.style.left = 320; counterHolder.style.top = (minOfWidthHeight - reduceSize) + 183;
      restartHolder.style.left = 40; restartHolder.style.top = (minOfWidthHeight - reduceSize) + 240;
      leaderboard.style.left = 40; leaderboard.style.top = (minOfWidthHeight - reduceSize) + 290;
      leaderboard.style.height = 600;
      leaderScores.style.height = 480;
    }

    canvasID.width  = minOfWidthHeight - reduceSize;
    canvasID.height = minOfWidthHeight - reduceSize;
    circlemask.style.width = minOfWidthHeight - (reduceSize - 10);
    circlemask.style.height = minOfWidthHeight - (reduceSize - 10);


    let genePoolIsDefined = typeof genePool != 'undefined';
    if ( genePoolIsDefined )
    {
        genePool.setCanvasDimensions( canvasID.width, canvasID.height );
    }

    // this successfully places an image in the background, and I can use clearRect
    // instead of fillrect in pool.render, but I don't yet know how to make the image scroll.

    /*
    canvasID.style.backgroundImage = "url( 'images/background.png' )";
    canvasID.style.backgroundSize = canvasID.width + "px " + canvasID.height + "px";
    canvasID.style.backgroundRepeat = "no-repeat";
    */

}


//------------------------------------------------------------
document.getElementById( 'circlemask' ).onmousedown = function(e)
{

    if ( typeof genePool != "undefined" )
    {
        genePool.touchDown( e.pageX - document.getElementById( 'Canvas' ).offsetLeft, e.pageY - document.getElementById( 'Canvas' ).offsetTop );
    }

}

//------------------------------------------------------------
document.getElementById( 'circlemask' ).onmousemove = function(e)
{
    if ( typeof genePool != "undefined" )
    {
        genePool.touchMove( e.pageX - document.getElementById( 'Canvas' ).offsetLeft, e.pageY - document.getElementById( 'Canvas' ).offsetTop );
    }
}

//------------------------------------------------------------
document.getElementById( 'circlemask' ).onmouseup = function(e)
{
    if ( typeof genePool != "undefined" )
    {
        genePool.touchUp( e.pageX - document.getElementById( 'Canvas' ).offsetLeft, e.pageY - document.getElementById( 'Canvas' ).offsetTop );
    }
}

//------------------------------------------------------------
document.getElementById( 'circlemask' ).onmouseout = function(e)
{
    if ( typeof genePool != "undefined" )
    {
        genePool.touchOut( e.pageX - document.getElementById( 'Canvas' ).offsetLeft, e.pageY - document.getElementById( 'Canvas' ).offsetTop );
    }
}


/*
//-------------------------------------------------------------------
// This is a rather hacky way of getting a two-finger translational
// gesture (a 2D vector) to be used for scrolling and stuff
//-------------------------------------------------------------------
window.onwheel = function(e)
{
    genePool.touchTwoFingerMove(e);
    //e.preventDefault();
}
*/

//--------------------------------
// key down
//--------------------------------
document.onkeydown = function(e)
{
    e = e || window.event;

    //-----------------------------
    // keys for camera navigation
    //-----------------------------
    let cameraNavAction = -1;

    if ( e.keyCode ===  37 ) // left arrow key
    {
        cameraNavAction = CameraNavigationAction.LEFT;

//unfinished work - I'm trying to make it so that when a camera nav button is pressed on the keyboard,
// the equivalent button highlights on the screen.
//document.getElementById( 'leftNav' ).style = 'background-image: url( "../../images/left-pressed.png" );'
//document.getElementById( 'leftNav'    ).style = "border-bottom-width: 3; border-bottom-left-radius: 4px; border-bottom-right-radius: 4px;"

    }

    if ( e.keyCode ===  39 ) { cameraNavAction = CameraNavigationAction.RIGHT;   } // right arrow key
    if ( e.keyCode ===  38 ) { cameraNavAction = CameraNavigationAction.UP;      } // up arrow key
    if ( e.keyCode ===  40 ) { cameraNavAction = CameraNavigationAction.DOWN;    } // down arrow key
    if ( e.keyCode ===  61 ) { cameraNavAction = CameraNavigationAction.IN;      } // plus key
    if ( e.keyCode === 173 ) { cameraNavAction = CameraNavigationAction.OUT;     } // minus key

    //apparently, Chrome and Safari  use different key codes...
    if ( e.keyCode === 187 ) { cameraNavAction = CameraNavigationAction.IN;      } // plus key
    if ( e.keyCode === 189 ) { cameraNavAction = CameraNavigationAction.OUT;     } // minus key

    if ( cameraNavAction != -1 )
    {
        if ( ! genePool.getCameraNavigationActive( cameraNavAction ) )
        {
            genePool.startCameraNavigation( cameraNavAction );
        }
    }

    //-----------------------------
    // other key pres events
    //-----------------------------
    /*
    if ( e.keyCode === 75 ) // K key
    {
        let selectedSwimbot = genePool.getSelectedSwimbotID();
        if ( selectedSwimbot != -1 )
        {
            genePool.killSwimbot( selectedSwimbot );
        }
    }
    if ( e.keyCode === 67 ) // C key
    {
        let selectedSwimbot = genePool.getSelectedSwimbotID();
        if ( selectedSwimbot != -1 )
        {
            genePool.cloneSwimbot( selectedSwimbot );
        }
    }
    */


    //console.log( "onkeydown " + e.keyCode );
}

//------------------------------
document.onkeyup = function(e)
{
    genePool.stopCameraNavigation( CameraNavigationAction.LEFT  );
    genePool.stopCameraNavigation( CameraNavigationAction.RIGHT );
    genePool.stopCameraNavigation( CameraNavigationAction.UP    );
    genePool.stopCameraNavigation( CameraNavigationAction.DOWN  );
    genePool.stopCameraNavigation( CameraNavigationAction.IN    );
    genePool.stopCameraNavigation( CameraNavigationAction.LEFT  );

/*
#leftNav
{
    left:   25;
    top:    30;
    background-image: url( "../images/left.png" );
}
*/

};

// ----- ZOOM SLIDER -----
var slider = document.getElementById("zoomSlider");
var output = document.getElementById("currentZoomUI");

// Update the current slider value (each time you drag the slider handle)
slider.oninput = function()
{
    // makes zoom non-linear for more control at close-up scale
    let zoomAmount = Math.sqrt( this.value / this.max );
    genePool.setCameraZoomAmount( zoomAmount );
}
